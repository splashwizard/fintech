<div class="modal fade" tabindex="-1" role="dialog" id="modal_success">
	<div class="modal-dialog modal-lg" role="document" style="margin-top: 400px;width:80px;height:80px;background-color:white;">
		<div>
			<div class="modal-body">
				<img src="{{ asset('img/tick.png') }}" alt="success image" style="width: 50px;height: 50px">
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

	