<div class="row">
    <div class="col-md-12">
        @component('components.widget', ['title' => __('lang_v1.more_info')])
            @include('user.form')
        @endcomponent
    </div>
</div>
