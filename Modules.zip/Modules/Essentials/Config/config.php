<?php

return [
    'name' => 'Essentials',
    'module_version' => '1.0'
];
