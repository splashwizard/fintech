<?php
 return [
"categories" => "Categorías",
"manage_your_categories" => "Administra tus categorías",
"all_your_categories" => "Todas tus categorías", /* modified */
"category" => "Categoría",
"category_name" => "Nombre de la categoría",
"code" => "Código de categoría",
"add_as_sub_category" => "Agregar como subcategoría",
"select_parent_category" => "Seleccionar categoría principal",
"added_success" => "Categoría añadida con éxito",
"updated_success" => "Categoría actualizada con éxito",
"deleted_success" => "Categoría borrada con éxito",
"add_category" => "Añadir categoría",
"edit_category" => "Editar categoria",
];
