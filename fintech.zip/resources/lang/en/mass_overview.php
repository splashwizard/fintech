<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Home Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used in home page.
    |
    */
    'serial' => 'serial',
    'company_name' => 'Company Name',
    'total_deposit' => 'Total Deposit',
    'total_withdrawal' => 'Total Withdrawal',
    'expense' => 'Expenses',
    'kiosk' => 'Kiosk',
    'borrow' => 'Borrow',
    'action' => 'Action',
    'all_companies' => 'All companies',
    'admin_added_success' => 'Admin added successfully'
];
