<?php
 return [
"stock_adjustment" => "ضبط المخزون",
"stock_adjustments" => "ضبط المخزونات",
"list" => "قائمة ضبط المخزون",
"add" => "أضف ضبط المخزون",
"all_stock_adjustments" => "جميع تعديلات المخزونات",
"search_product" => "البحث عن المنتجات",
"adjustment_type" => "نوع الضبط",
"normal" => "عادي",
"abnormal" => "غير عادي",
"total_amount" => "المبلغ الإجمالي",
"total_amount_recovered" => "المبلغ الإجمالي المسترد",
"reason_for_stock_adjustment" => "السبب",
"stock_adjustment_added_successfully" => "تمت إضافة ضبط المخزون بنجاح",
"search_products" => "البحث عن المنتجات",
"delete_success" => "تم حذف ضبط المخزون بنجاح",
"view_details" => "عرض تفاصيل ضبط المخزون",
];
