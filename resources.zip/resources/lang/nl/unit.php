<?php
 return [
"units" => "Eenheden",
"manage_your_units" => "Beheer uw eenheden",
"all_your_units" => "Al uw eenheden",
"name" => "Naam",
"short_name" => "Korte naam",
"allow_decimal" => "Decimaal toestaan",
"added_success" => "Unit succesvol toegevoegd",
"updated_success" => "Unit succesvol bijgewerkt",
"deleted_success" => "Unit succesvol verwijderd",
"add_unit" => "Voeg eenheid toe",
"edit_unit" => "Bewerk eenheid",
];
