<?php

return [
    'active'        => 'Active',
    'available'     => 'Available',
    'dark_mode'     => 'Dark Mode',
    'disabled'      => 'Disabled',
    'invisible'     => 'Invisible',
    'enabled'       => 'Enabled',
    'notifications' => 'Notifications',
    'notify_no'     => 'Do not disturb',
    'notify_yes'    => 'Be notified',
    'settings'      => 'Settings',
    'status'        => 'Online Status',
];
