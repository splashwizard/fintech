<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Expense Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used for Expense CRUD operations.
    |
    */

    'title' => 'Daily Report',
    'all_banks' => 'All banks',
    'all_services' => 'All services'
];
